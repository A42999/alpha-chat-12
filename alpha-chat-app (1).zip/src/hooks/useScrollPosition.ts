// useScrollPosition.ts - For scroll position tracking logic
