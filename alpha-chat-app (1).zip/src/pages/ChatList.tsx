// ChatList.tsx - Placeholder content
